This is a simple pizza game project for Android using Unity.
Features:
- Drag & Drop pizza making
- Simple earnings system
- Ad button to double earnings for 5 minutes
- Arabic and English UI
